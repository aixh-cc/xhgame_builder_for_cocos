// 定义微信全局变量ws
declare const wx;

// 抖音
declare const tt;