import { BattleModelComp } from "./comps/models/BattleModelComp";
import { PlayerModelComp } from "./comps/models/PlayerModelComp";
import { PlayerLoginComp } from "./comps/player/PlayerLoginComp";

export class RegisterComps {
    ['PlayerLoginComp']: typeof PlayerLoginComp = PlayerLoginComp;  // 手动注册
    ['PlayerModelComp']: typeof PlayerModelComp = PlayerModelComp;  // 手动注册
    ['BattleModelComp']: typeof BattleModelComp = BattleModelComp;
}