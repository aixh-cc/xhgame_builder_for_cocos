import { AudioManager, DI, IAudioDrive } from "@aixh-cc/xhgame_ec_framework"

/** 音效管理 */
export class MyAudioManager<T extends IAudioDrive> extends AudioManager<T> {
    constructor() {
        super(DI.make("IAudioDrive"))
    }
    get enums() {
        return AudioEnums
    }
}

enum AudioEnums {
}