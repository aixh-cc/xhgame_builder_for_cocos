import { EventManager } from "@aixh-cc/xhgame_ec_framework"

/** 事件管理 */
export class MyEventManager extends EventManager {
    get enums() {
        return EventEnums
    }
}

export enum EventEnums {

}