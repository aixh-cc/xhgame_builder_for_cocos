import { DI, INode, IUiDrive, UiManager } from "@aixh-cc/xhgame_ec_framework"

/** ui管理 */
export class MyUiManager<T extends IUiDrive, NT extends INode> extends UiManager<T, NT> {

    constructor() {
        super(DI.make('IUiDrive'))
    }

    get enums() {
        return UIEnums
    }
}

enum UIEnums {
}