import { IFactoryConfig } from "@aixh-cc/xhgame_ec_framework";
import { FactoryType } from "../MyFactoryManager";

export class MyCocosFactoryConfig implements IFactoryConfig {
}
const getFactoryType = () => {
    return FactoryType // 主要是为了 FactoryType 被正常使用着,不要被脚本去除无用引用给去除了
}